<?php
echo '
<ul>
    <li><a href="index.php">KYS Ana Sayfa</a></li>
    <li><a href="yonetici_paneli.php">Yönetici Giriş Sayfası</a></li>
    <li><a href="kym.php">Kullanıcı Yönetimi</a></li>
    <li><a href="mym.php">Materyal Yönetimi</a></li>
    <li><a href="dym.php">Dolaşım Modülü</a></li>
    <li><a href="rim.php">Raporlama Modülü</a></li>
    <li><a href="cikis.php">Çıkış</a></li>
</ul>'
?>